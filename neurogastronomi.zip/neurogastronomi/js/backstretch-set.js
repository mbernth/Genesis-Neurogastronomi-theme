jQuery(document).ready(function($) {

	$(".front-page-1").backstretch([BackStretchImg.src]);

});